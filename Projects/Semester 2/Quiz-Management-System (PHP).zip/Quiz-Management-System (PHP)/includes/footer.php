<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src='https://code.jquery.com/jquery-3.6.0.min.js'></script>
<script src="https://cdn.jsdelivr.net/npm/appwrite@16.0.2"></script>
<script>
    const { Client } = Appwrite;
    const client = new Client();
    client.setProject('673d9dd1003dbf68a6de');
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>